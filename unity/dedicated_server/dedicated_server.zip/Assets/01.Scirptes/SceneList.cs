using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SceneList
{
    public const string Bootstrap = "Bootstrap";
    public const string Menu = "Menu";
    public const string Game = "Game";
}
